//20125012
//Nguyen Duc Manh
//20CTT1

#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
    string s; cin >> s;
    reverse(s.begin(), s.end());
    cout << s;
}
